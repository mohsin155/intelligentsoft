<?php

return [
    "login_fail" => 'Invalid Email or Password',
    "user_deleted"=>'User deleted successfully !!!',
    "password_length" => 'password must be of atleast 6 chracters',
    "password_not_match" => 'Old password do not match',
    "new_password_match" => "New Password doesn't Match with Confirm Password",
    "password_changed" => "Your password changed successfully",
    "department_created" => "Department created successfully",
    "unauthorize" => "You donot have the priviledge to access this page.",
    "task_created" => "Task created successfully",
];