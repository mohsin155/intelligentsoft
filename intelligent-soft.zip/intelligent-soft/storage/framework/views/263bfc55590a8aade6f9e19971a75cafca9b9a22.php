<?php $__env->startSection('content'); ?>
<div id="page-wrapper" style="width:35%;text-align: center;margin-left: 204px;min-height:auto !important;">

    <div class="container-fluid">


        <div class="row">
            <div class="col-lg-12"><?php if(!empty($errors) && count($errors)>0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach($errors as $messages): ?>
                    <li> <?php echo e($messages); ?> </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>
                <form role="form" method="post" action="<?php echo e(url('users/login')); ?>"}}">
                    <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                    <div class="form-group">
                        <label>Username/Email</label>
                        <input type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" class="form-control" name="password">
                    </div>
                    <button type="submit" class="btn btn-default">Log In</button>
                </form>
            </div></div>
    </div></div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>