<div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li class="active">
                        <a href="<?php echo e(url('users/dashboard')); ?>"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('users/user-list')); ?>"><i class="fa fa-fw fa-user"></i> Clients</a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('category/category-list')); ?>"><i class="fa fa-fw fa-cubes"></i> Categories</a>
                    </li>
                </ul>
            </div>